<footer class="footer bg-dark">
  <div class="container">
    <span class="text-muted">&copy 2019 Team Puma<br/>
      <a href="https://www.metrostate.edu">Metropolitan State University</a><br/>
  </div>
</footer>